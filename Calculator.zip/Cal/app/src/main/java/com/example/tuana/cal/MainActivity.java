package com.example.tuana.cal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String arr[] = {"","","","Delete","7","8","9","/","4","5","6","*","1","2","3","-",".","0","=","+"};
    String name = "";
    int number1, number2 = 0;
    int number3 = 0;
    String arr1[];
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_layout);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final EditText txt = (EditText) findViewById(R.id.txtView);
        final GridView gr = (GridView) findViewById(R.id.gripView1);
        ArrayAdapter<String> da = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                arr
        );

        gr.setAdapter(da);
        gr.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> agr0, View agr1, int agr2, long agr3){
                String c = String.valueOf(txt.getText());
                String m = arr[agr2];
                String s = tinhtoan(c, m);
                txt.setText(s);
            }
        });

    }
    public String tinhtoan(String c, String m){
        String kq;
        kq = c + m;

        if(m.equals(".")){
            if(c.contains(".")){
                kq = c;
            }
        }

        if(c.equals("0")){
            if(m.equals("0")||m.equals("1")||m.equals("2")||m.equals("3")||m.equals("4")||m.equals("5")||m.equals("6")||m.equals("7")||m.equals("8")||m.equals("9")){
                kq = m;
            }
        }

        if(m.equals("Delete")){
            kq = "";
        }

        if(m.equals("+")){
            //number1 = Integer.parseInt(c + "");
            name = "+";
            kq = c+m;

        }

        if(m.equals("-")){
            //number1 = Integer.parseInt(c + "");
            name = "-";
            kq = c+m;

        }

        if(m.equals("*")){
            //number1 = Integer.parseInt(c + "");
            name = "*";
            kq = c+m;
        }

        if(m.equals("/")){
            //number1 = Integer.parseInt(c + "");
            name = "/";
            kq = c+m;
        }

        if(m.equals("=")){
            //number2 = Integer.parseInt(c + "");
            if(name.equals("")){
                String arr1[] = c.split("[=]");
                for(int i = 0; i < arr1.length; i++){
                    number3 = number3 + Integer.parseInt(arr1[i] + "");
                }
                kq = String.valueOf(number3);
                number3 = 0;
            }

            if(name.equals("+")){
                String arr1[] = c.split("[+]");
                for(int i = 0; i < arr1.length; i++){
                    if(arr1[i] == ""){
                        arr1[i] = "0";
                    }
                    number3 = number3 + Integer.parseInt(arr1[i]+ "");
                }
                kq = String.valueOf(number3);
                number3 = 0;
            }
            if(name.equals("-")){
                String arr1[] = c.split("[-]");
                for(int i = 0; i < arr1.length; i++){
                    number3 = Integer.parseInt(arr1[0]);
                    for(int j = 1; j < arr1.length; j++) {
                        number3 = number3 - Integer.parseInt(arr1[j]);
                    }
                }
                kq = String.valueOf(number3);
                number3 = 0;
            }
            if(name.equals("*")){
                String arr1[] = c.split("[*]");
                for(int i = 0; i < arr1.length; i++){
                    number3 = Integer.parseInt(arr1[0]);
                    for(int j = 1; j < arr1.length; j++) {
                        number3 = number3 * Integer.parseInt(arr1[j]);
                    }
                }
                kq = String.valueOf(number3);
                number3 = 0;
            }
            if(name.equals("/")){
                String arr1[] = c.split("[/]");
                for(int i = 0; i < arr1.length; i++){
                    number3 = Integer.parseInt(arr1[0]);
                    for(int j = 1; j < arr1.length; j++) {
                        number3 = number3 / Integer.parseInt(arr1[j]);
                    }
                }
                kq = String.valueOf(number3);
                number3 = 0;
            }
            name = "=";
        }
        if(name.equals("=")){
            if(m.equals("0")||m.equals("1")||m.equals("2")||m.equals("3")||m.equals("4")||m.equals("5")||m.equals("6")||m.equals("7")||m.equals("8")||m.equals("9")){
                kq = m;
                name = "";
            }

        }

        return kq;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
